package com.example.flutter_budget_tracking_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
